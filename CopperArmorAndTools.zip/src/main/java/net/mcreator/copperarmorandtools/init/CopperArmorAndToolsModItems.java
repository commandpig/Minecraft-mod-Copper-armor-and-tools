
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.copperarmorandtools.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.copperarmorandtools.item.RustRemoverItem;
import net.mcreator.copperarmorandtools.item.RustIngotItem;
import net.mcreator.copperarmorandtools.item.CopperSwordItem;
import net.mcreator.copperarmorandtools.item.CopperStickItem;
import net.mcreator.copperarmorandtools.item.CopperShovelItem;
import net.mcreator.copperarmorandtools.item.CopperRustItem;
import net.mcreator.copperarmorandtools.item.CopperPickaxeItem;
import net.mcreator.copperarmorandtools.item.CopperHoeItem;
import net.mcreator.copperarmorandtools.item.CopperAxeItem;
import net.mcreator.copperarmorandtools.item.CopperArmorItem;
import net.mcreator.copperarmorandtools.CopperArmorAndToolsMod;

public class CopperArmorAndToolsModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, CopperArmorAndToolsMod.MODID);
	public static final RegistryObject<Item> COPPER_AXE = REGISTRY.register("copper_axe", () -> new CopperAxeItem());
	public static final RegistryObject<Item> COPPER_PICKAXE = REGISTRY.register("copper_pickaxe", () -> new CopperPickaxeItem());
	public static final RegistryObject<Item> COPPER_SWORD = REGISTRY.register("copper_sword", () -> new CopperSwordItem());
	public static final RegistryObject<Item> COPPER_SHOVEL = REGISTRY.register("copper_shovel", () -> new CopperShovelItem());
	public static final RegistryObject<Item> COPPER_HOE = REGISTRY.register("copper_hoe", () -> new CopperHoeItem());
	public static final RegistryObject<Item> COPPER_ARMOR_HELMET = REGISTRY.register("copper_armor_helmet", () -> new CopperArmorItem.Helmet());
	public static final RegistryObject<Item> COPPER_ARMOR_CHESTPLATE = REGISTRY.register("copper_armor_chestplate", () -> new CopperArmorItem.Chestplate());
	public static final RegistryObject<Item> COPPER_ARMOR_LEGGINGS = REGISTRY.register("copper_armor_leggings", () -> new CopperArmorItem.Leggings());
	public static final RegistryObject<Item> COPPER_ARMOR_BOOTS = REGISTRY.register("copper_armor_boots", () -> new CopperArmorItem.Boots());
	public static final RegistryObject<Item> COPPER_BUTTON = block(CopperArmorAndToolsModBlocks.COPPER_BUTTON, CreativeModeTab.TAB_REDSTONE);
	public static final RegistryObject<Item> COPPER_PRESSURE_PLATE = block(CopperArmorAndToolsModBlocks.COPPER_PRESSURE_PLATE, CreativeModeTab.TAB_REDSTONE);
	public static final RegistryObject<Item> COPPER_STICK = REGISTRY.register("copper_stick", () -> new CopperStickItem());
	public static final RegistryObject<Item> RUST_REMOVER = REGISTRY.register("rust_remover", () -> new RustRemoverItem());
	public static final RegistryObject<Item> COPPER_RUST = REGISTRY.register("copper_rust", () -> new CopperRustItem());
	public static final RegistryObject<Item> RUST_INGOT = REGISTRY.register("rust_ingot", () -> new RustIngotItem());
	public static final RegistryObject<Item> RUST_BLOCK = block(CopperArmorAndToolsModBlocks.RUST_BLOCK, CreativeModeTab.TAB_BUILDING_BLOCKS);

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
