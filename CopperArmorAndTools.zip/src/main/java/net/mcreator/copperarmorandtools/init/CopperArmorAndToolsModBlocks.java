
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.copperarmorandtools.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;

import net.mcreator.copperarmorandtools.block.RustBlockBlock;
import net.mcreator.copperarmorandtools.block.CopperPressurePlateBlock;
import net.mcreator.copperarmorandtools.block.CopperButtonBlock;
import net.mcreator.copperarmorandtools.CopperArmorAndToolsMod;

public class CopperArmorAndToolsModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, CopperArmorAndToolsMod.MODID);
	public static final RegistryObject<Block> COPPER_BUTTON = REGISTRY.register("copper_button", () -> new CopperButtonBlock());
	public static final RegistryObject<Block> COPPER_PRESSURE_PLATE = REGISTRY.register("copper_pressure_plate", () -> new CopperPressurePlateBlock());
	public static final RegistryObject<Block> RUST_BLOCK = REGISTRY.register("rust_block", () -> new RustBlockBlock());

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			CopperButtonBlock.registerRenderLayer();
			CopperPressurePlateBlock.registerRenderLayer();
		}
	}
}
