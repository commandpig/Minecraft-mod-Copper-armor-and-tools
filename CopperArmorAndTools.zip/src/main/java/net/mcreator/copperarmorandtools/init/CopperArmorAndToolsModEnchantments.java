
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.copperarmorandtools.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.enchantment.Enchantment;

import net.mcreator.copperarmorandtools.enchantment.RustEnchantment;
import net.mcreator.copperarmorandtools.CopperArmorAndToolsMod;

public class CopperArmorAndToolsModEnchantments {
	public static final DeferredRegister<Enchantment> REGISTRY = DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, CopperArmorAndToolsMod.MODID);
	public static final RegistryObject<Enchantment> RUST = REGISTRY.register("rust", () -> new RustEnchantment());
}
