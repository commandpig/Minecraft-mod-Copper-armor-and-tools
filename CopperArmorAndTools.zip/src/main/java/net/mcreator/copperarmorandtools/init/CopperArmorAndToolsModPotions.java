
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.copperarmorandtools.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.copperarmorandtools.CopperArmorAndToolsMod;

public class CopperArmorAndToolsModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(ForgeRegistries.POTIONS, CopperArmorAndToolsMod.MODID);
	public static final RegistryObject<Potion> POISONOUS_RUST = REGISTRY.register("poisonous_rust", () -> new Potion(new MobEffectInstance(MobEffects.POISON, 600, 0, false, true), new MobEffectInstance(MobEffects.CONFUSION, 200, 0, false, true)));
}
