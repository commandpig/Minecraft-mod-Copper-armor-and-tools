
package net.mcreator.copperarmorandtools.enchantment;

import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.enchantment.EnchantmentCategory;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.EquipmentSlot;

import net.mcreator.copperarmorandtools.init.CopperArmorAndToolsModItems;

import java.util.List;

public class RustEnchantment extends Enchantment {
	public RustEnchantment(EquipmentSlot... slots) {
		super(Enchantment.Rarity.UNCOMMON, EnchantmentCategory.BREAKABLE, slots);
	}

	@Override
	public int getMaxLevel() {
		return 3;
	}

	@Override
	protected boolean checkCompatibility(Enchantment ench) {
		return !List.of(Enchantments.FIRE_ASPECT).contains(ench);
	}

	@Override
	public boolean canApplyAtEnchantingTable(ItemStack stack) {
		Item item = stack.getItem();
		return List.of(CopperArmorAndToolsModItems.COPPER_PICKAXE.get(), CopperArmorAndToolsModItems.COPPER_AXE.get(), CopperArmorAndToolsModItems.COPPER_SWORD.get(), CopperArmorAndToolsModItems.COPPER_SHOVEL.get(),
				CopperArmorAndToolsModItems.COPPER_HOE.get()).contains(item);
	}
}
